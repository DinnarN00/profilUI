# Profile_UI
Tugas Mobile Programing

![UI](https://user-images.githubusercontent.com/100903781/161421604-1f4d69ca-feb7-4e27-97ff-8c4d1f329498.png)

![UI 2](https://user-images.githubusercontent.com/100903781/161421649-4487b0bd-78d3-4bf4-8a2c-62876ffefc9c.jpg)
